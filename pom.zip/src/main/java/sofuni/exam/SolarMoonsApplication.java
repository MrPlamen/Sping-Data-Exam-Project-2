package sofuni.exam;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SolarMoonsApplication {

    public static void main(String[] args) {
        SpringApplication.run(SolarMoonsApplication.class, args);
    }

}
