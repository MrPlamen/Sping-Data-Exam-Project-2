INSERT INTO discoverers (first_name, last_name, nationality, occupation)
VALUES ('Galileo', 'Galilei', 'Italian', 'astronomer'),
       ('Christiaan', 'Huygens', 'Dutch', 'mathematician'),
       ('Giovanni', 'Cassini', 'Italian', 'astronomer'),
       ('William', 'Herschel', 'German-British', 'astronomer'),
       ('Gerard', 'Kuiper', 'Dutch-American', 'planetary scientist'),
       ('Asaph', 'Hall', 'American', 'mathematician'),
       ('William', 'Lassell', 'British', 'merchant'),
       ('James', 'Christy', 'American', 'astronomer'),
       ('Stephen', 'Synnott', 'American', 'scientist');
